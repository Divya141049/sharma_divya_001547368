/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info5100.university.Assignment_3;
import com.github.javafaker.Faker;
import info5100.university.example.CourseCatalog.Course;
import info5100.university.example.CourseCatalog.CourseCatalog;
import info5100.university.example.Department.Department;
import info5100.university.example.Department.DepartmentDirectory;
import info5100.university.example.Faculty.FacultyDirectory;
import info5100.university.example.Faculty.FacultyProfile;
import info5100.university.example.Person.Person;
import info5100.university.example.Person.PersonDirectory;
import info5100.university.example.Student.StudentDirectory;
import info5100.university.example.Student.StudentProfile;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author kal bugrara
 */
public class Info5001University_Main {

    public static ArrayList<Person> person  =  PersonDirectory.newPerson();
    public static ArrayList<StudentProfile> student = StudentDirectory.newStudentProfile();
    public static ArrayList<FacultyProfile> faculty = FacultyDirectory.newFacultyProfile();
    public static ArrayList<Course> cc = CourseCatalog.newCourse();
    public static ArrayList<Department> d = DepartmentDirectory.newDepartment();
    Faker faker = new Faker();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        //Load faker data
        loadFaker();
        Scanner sc = new Scanner(System.in);
         
        System.out.println("University Model\nPlease select an option to proceed : \n");
        System.out.println("1. Student Details");
        System.out.println("2. Department Details");
        System.out.println("3. Faculty Details");
        System.out.println("4. Department Details\n");
         
        String option = sc.nextLine();
        String choice = "YES";
        while(choice.equalsIgnoreCase("yes")){
       switch(option) {
           case "1": StudentDirectory.viewStudentDir();
           
            break;
           default: System.out.println("Invalid selection. Try again.");
         
                   }
       System.out.println("\n***********\nDo you wish to continue? Enter YES or NO.");
        choice = sc.nextLine();
        
        }
    }

    
    public static void loadFaker(){
    
        // TODO code application logic here
        int count = 0;
        while (count < 50)
        {
            Faker faker = new Faker();
            Person p = new Person(faker.name().fullName().toString(),faker.date().birthday(18, 80),
                    faker.address().streetAddress(),faker.address().zipCode(),faker.idNumber().valid());
            person.add(p);
            
            count++;
        }
        // For Department 1
        while (count < 5)
        {
            Faker faker = new Faker();
            Course course;
            course = new Course("Information Systems",faker.app().name(), faker.code().toString(), faker.number().numberBetween(10, 60));
            Department d = new Department("Information Systems");
          
            cc.add(course);
            
        }
        //Department d1 = new Department("Information Systems", "College of Enginneering",cc,person,student,faculty);
 
        while (count < 5)
        {
            Faker faker = new Faker();
            Course course;
            course = new Course("Computer Science Engineering",faker.app().name(), faker.code().toString(), faker.number().numberBetween(10, 60));
            Department d = new Department("Computer Science Engineering");
        
            cc.add(course);
        }
        
        Department d = new Department();
//        int total = d.calculateRevenuesBySemester("Fall2020");
//        System.out.print("Total: " + total);

    }
}
