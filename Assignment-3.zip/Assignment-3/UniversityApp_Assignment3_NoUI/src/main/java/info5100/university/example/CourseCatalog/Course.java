/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info5100.university.example.CourseCatalog;

import info5100.university.example.Department.Department;
import java.util.Date;

/**
 *
 * @author kal bugrara
 */
public class Course {
    String department;
    Date lastupdated;
    String number;
    String name;
    int credits;
    int price = 1500; //per credit hour
    
    public Course(String d, String n, String numb, int ch){
        department = d;
//        lastupdated = dd;
        name = n;
        number = numb;
        credits = ch;
    }

    public Course() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public String getCOurseNumber(){
        return number;
    }
    
    public int getCoursePrice(){
        return price*credits;
        
    }
}
