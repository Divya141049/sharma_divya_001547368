/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info5100.university.example.CourseCatalog;

import info5100.university.example.Department.Department;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author kal bugrara
 */
public class CourseCatalog {
    static ArrayList<Course> courselist; 

    public CourseCatalog(ArrayList<Course> courselist) {
        this.courselist = courselist;
    }

    public CourseCatalog() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    public ArrayList<Course> getCourseList(){
        return courselist;
    }
    
     public static ArrayList<Course> newCourse(){
        courselist = new ArrayList<Course>();
        return courselist;
    }
    
    public static Course getCourseByNumber(String n){
        
        for( Course c: courselist){
            
            if(c.getCOurseNumber().equals(n)) return c;
        }
        return null;
    }

}