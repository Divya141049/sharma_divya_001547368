/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info5100.university.example.Department;

import info5100.university.example.CourseCatalog.Course;
import info5100.university.example.CourseCatalog.CourseCatalog;
import info5100.university.example.CourseSchedule.CourseLoad;
import info5100.university.example.CourseSchedule.CourseOffer;
import info5100.university.example.CourseSchedule.CourseSchedule;
import info5100.university.example.Faculty.FacultyProfile;
import info5100.university.example.Person.Person;
import info5100.university.example.Student.StudentDirectory;
import info5100.university.example.Student.StudentProfile;
import java.util.HashMap;

/**
 *
 * @author kal bugrara
*/

public class Department {

    String name;
    String college;
    Course coursecatalog;
    Person persondirectory;
    StudentProfile studentdirectory;
    FacultyProfile facultydirectory;
    HashMap<String, CourseSchedule> mastercoursecatalog;

    //EmployerDirectory employerdirectory;

//    public Department() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
    public Department(){
    
}
    
    public Department(String s, CourseSchedule cs){
        
        mastercoursecatalog.put(s,cs);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public Course getCoursecatalog() {
        return coursecatalog;
    }

    public void setCoursecatalog(Course coursecatalog) {
        this.coursecatalog = coursecatalog;
    }

    public Person getPersondirectory() {
        return persondirectory;
    }

    public void setPersondirectory(Person persondirectory) {
        this.persondirectory = persondirectory;
    }

    public StudentProfile getStudentdirectory() {
        return studentdirectory;
    }

    public void setStudentdirectory(StudentProfile studentdirectory) {
        this.studentdirectory = studentdirectory;
    }

    public FacultyProfile getFacultydirectory() {
        return facultydirectory;
    }

    public void setFacultydirectory(FacultyProfile facultydirectory) {
        this.facultydirectory = facultydirectory;
    }

    public HashMap<String, CourseSchedule> getMastercoursecatalog() {
        return mastercoursecatalog;
    }

    public void setMastercoursecatalog(HashMap<String, CourseSchedule> mastercoursecatalog) {
        this.mastercoursecatalog = mastercoursecatalog;
    }

   

    public Department(String name, String college, Course coursecatalog, Person persondirectory, StudentProfile studentdirectory, FacultyProfile facultydirectory) {
        this.name = name;
        this.college = college;
        this.coursecatalog = coursecatalog;
        this.persondirectory = persondirectory;
        this.studentdirectory = studentdirectory;
        this.facultydirectory = facultydirectory;
        this.mastercoursecatalog = mastercoursecatalog;
    }
    
    public Department(String name)
    {
        this.name = name;
    }


    

    public Person getPersonDirectory() {

        return persondirectory;

    }

    public StudentProfile getStudentDirectory() {
    return studentdirectory;
    }

    public CourseSchedule newCourseSchedule(String semester) {

        CourseSchedule cs = new CourseSchedule(semester, coursecatalog);
        mastercoursecatalog.put(semester, cs);
        return cs;
    }

    public CourseSchedule getCourseSchedule(String semester) {

        return mastercoursecatalog.get(semester);

    }

    public Course getCourseCatalog() {

        return coursecatalog;

    }
    public int calculateRevenuesBySemester(String semester) {

        CourseSchedule css = mastercoursecatalog.get(semester);

        return css.calculateTotalRevenues();

    }

    public void RegisterForAClass(String studentid, String cn, String semester) {

        StudentProfile sp = StudentDirectory.findStudent(studentid);

        CourseLoad cl = sp.getCurrentCourseLoad();

        CourseSchedule cs = mastercoursecatalog.get(semester);

        CourseOffer co = cs.getCourseOfferByNumber(cn);

        co.assignEmptySeat(cl);

    }
}
