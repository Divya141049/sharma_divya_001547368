/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info5100.university.example.Department;

import java.util.ArrayList;

/**
 *
 * @author charusingh
 */
public class DepartmentDirectory {
    static ArrayList<Department> departmentList;

    public DepartmentDirectory() {
        departmentList = new ArrayList();
    }
    
    public static ArrayList<Department> newDepartment() {
        departmentList = new ArrayList<Department>();
        return departmentList;
    }
    
    
}
