/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info5100.university.example.Student;

import info5100.university.example.Department.Department;
import info5100.university.example.Person.Person;
import java.util.ArrayList;

/**
 *
 * @author kal bugrara
 */
public class StudentDirectory {

    public static ArrayList<StudentProfile> studentlist;

    public StudentDirectory() {
        studentlist = new ArrayList();
    }

    public static ArrayList<StudentProfile> newStudentProfile() {
        studentlist = new ArrayList<StudentProfile>();
        return studentlist;
    }

    public StudentDirectory(Department aThis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static StudentProfile findStudent(String id) {

        for (StudentProfile sp : studentlist) {

            if (sp.isMatch(id)) {
                return sp;
            }
        }
            return null; //not found after going through the whole list
         }
    
    public static void viewStudentDir() {
		int i=0;
		if(!studentlist.isEmpty())
		{for (StudentProfile student : studentlist) {
				System.out.println("\n" + (++i) + " : ");
			System.out.println("Student ID : "+student.getPersonId());
			//System.out.println("Patient ID : "+patient.getPatientID());
			System.out.println("Student Details : "+student.person);
			
			}
		}
		else { 
			System.out.println("Student not found. Please enter details first.");
		}
	}
}
