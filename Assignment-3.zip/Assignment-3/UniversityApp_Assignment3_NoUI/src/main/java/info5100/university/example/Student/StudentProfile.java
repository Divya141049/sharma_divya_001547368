/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info5100.university.example.Student;

import info5100.university.example.CourseSchedule.CourseLoad;
import info5100.university.example.Department.Department;
import info5100.university.example.EmploymentHistory.EmploymentHistroy;
import info5100.university.example.Person.Person;
import java.util.Date;

/**
 *
 * @author kal bugrara
 */
public class StudentProfile extends Person{

    Person person;
    Department department;
    Transcript transcript;

    public StudentProfile(Person person, Department department, Transcript transcript, EmploymentHistroy employmenthistory, String name, Date dob, String address, String zipCode, String personID) {
        super(name, dob, address, zipCode, personID);
        this.person = person;
        this.department = department;
        this.transcript = transcript;
        this.employmenthistory = employmenthistory;
    }
    EmploymentHistroy employmenthistory;
    

    public StudentProfile(Person p) {

        person = p;
        transcript = new Transcript();
        employmenthistory = new EmploymentHistroy();
    }

    public boolean isMatch(String id) {
        if (person.getPersonId().equals(id)) {
            return true;
        }
        return false;
    }

    public CourseLoad getCourseLoadBySemester(String semester) {

        return transcript.getCourseLoadBySemester(semester);
    }

    public CourseLoad getCurrentCourseLoad() {

        return transcript.getCurrentCourseLoad();
    }

    public CourseLoad newCourseLoad(String s){
        
        return transcript.newCourseLoad(s);
    }
}
